import controle.ControladorPrincipal;

public class SistemaChamadosMain {
	
	public static void main(String[] args){
		
		new ControladorPrincipal().start();
	}
	
}
